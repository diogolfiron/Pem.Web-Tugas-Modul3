// src/components/Hero.js
import React from "react";

function Hero() {
  return (
    <div>
      <h1>Welcome to our Website</h1>
      <p>Saya Reynaldio Ajisakti Golfiron</p>
    </div>
  );
}

export default Hero;

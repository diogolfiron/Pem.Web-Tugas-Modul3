// src/pages/Menu.js
import React from 'react';
import bg from '../assets/background5.jpg';

function Menu() {
  return (
    <div>
      <h2>Menu</h2>
      <img src={bg} alt='tes'></img>
    </div>
  );
}

export default Menu;



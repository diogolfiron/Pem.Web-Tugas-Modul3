// src/pages/About.js
import React from 'react'

const AboutPage = () => {
  return (
    <div> <h2>About us</h2></div>
  )
}

export default AboutPage
